// export class id {
//     constructor(public id: number,

//     ) {

//     }
// }