import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activites-view',
  templateUrl: './activites-view.component.html',
  styleUrls: ['./activites-view.component.scss']
})
export class ActivitesViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
