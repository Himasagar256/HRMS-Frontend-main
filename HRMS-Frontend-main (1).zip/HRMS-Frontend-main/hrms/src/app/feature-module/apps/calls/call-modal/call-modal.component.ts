import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-call-modal',
  templateUrl: './call-modal.component.html',
  styleUrls: ['./call-modal.component.scss']
})
export class CallModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
