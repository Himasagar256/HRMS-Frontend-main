import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-incoming-call',
  templateUrl: './incoming-call.component.html',
  styleUrls: ['./incoming-call.component.scss'],
  // encapsulation: ViewEncapsulation.None,

})
export class IncomingCallComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
