import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-outgoing-call',
  templateUrl: './outgoing-call.component.html',
  styleUrls: ['./outgoing-call.component.scss'],
  // encapsulation: ViewEncapsulation.None,

})
export class OutgoingCallComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
