import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voice-call',
  templateUrl: './voice-call.component.html',
  styleUrls: ['./voice-call.component.scss']
})
export class VoiceCallComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
