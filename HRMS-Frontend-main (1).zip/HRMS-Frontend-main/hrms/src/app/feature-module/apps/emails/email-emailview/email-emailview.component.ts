import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-emailview',
  templateUrl: './email-emailview.component.html',
  styleUrls: ['./email-emailview.component.css']
})
export class EmailEmailviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
