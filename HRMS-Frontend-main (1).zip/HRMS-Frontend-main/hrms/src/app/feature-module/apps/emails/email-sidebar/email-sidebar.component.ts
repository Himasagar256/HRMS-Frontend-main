import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-sidebar',
  templateUrl: './email-sidebar.component.html',
  styleUrls: ['./email-sidebar.component.scss']
})
export class EmailSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
