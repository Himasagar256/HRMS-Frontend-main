import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clients-profile',
  templateUrl: './clients-profile.component.html',
  styleUrls: ['./clients-profile.component.scss']
})
export class ClientsProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
