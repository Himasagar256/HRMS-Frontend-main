import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviewing-jobs',
  templateUrl: './interviewing-jobs.component.html',
  styleUrls: ['./interviewing-jobs.component.scss']
})
export class InterviewingJobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
