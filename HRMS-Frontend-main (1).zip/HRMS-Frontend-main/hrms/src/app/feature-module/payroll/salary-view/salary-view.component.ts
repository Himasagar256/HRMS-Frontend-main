import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salary-view',
  templateUrl: './salary-view.component.html',
  styleUrls: ['./salary-view.component.scss']
})
export class SalaryViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
