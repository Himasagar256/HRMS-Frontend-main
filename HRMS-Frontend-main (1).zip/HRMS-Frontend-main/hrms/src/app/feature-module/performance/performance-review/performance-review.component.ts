import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-performance-review',
  templateUrl: './performance-review.component.html',
  styleUrls: ['./performance-review.component.scss']
})
export class PerformanceReviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
