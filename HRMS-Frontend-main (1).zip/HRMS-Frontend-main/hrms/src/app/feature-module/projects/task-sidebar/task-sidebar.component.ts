import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-sidebar',
  templateUrl: './task-sidebar.component.html',
  styleUrls: ['./task-sidebar.component.scss']
})
export class TaskSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
